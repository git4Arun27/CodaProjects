# BoltNutLug-Prediction > 2024-10-03 9:11am
https://universe.roboflow.com/object-detection-using-yolov5-utvob/boltnutlug-prediction

Provided by a Roboflow user
License: Public Domain

