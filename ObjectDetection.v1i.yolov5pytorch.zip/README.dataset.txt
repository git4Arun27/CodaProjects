# ObjectDetection > 2024-09-19 9:01am
https://universe.roboflow.com/object-detection-using-yolov5-utvob/objectdetection-blca3

Provided by a Roboflow user
License: CC BY 4.0

