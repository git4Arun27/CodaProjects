# InHandPrediction > 2024-10-04 7:47am
https://universe.roboflow.com/object-detection-using-yolov5-utvob/inhandprediction

Provided by a Roboflow user
License: Public Domain

